## Apexion Velocity 15 (VG15-32P-30YE)

**Top pick: The best Windows laptop under $500**

Unlike most cheap Windows laptops, this Velocity Go 15 model is fast, has a decent 1080p display, and conveniently charges via USB-C.

If you need a Windows laptop for home, work, or school — and you can't afford to spend a lot — you can find a decent one for less than $500. These computers are ideal for people on a strict budget, grade-school and middle-school students, and those who use their computers mostly at home in the evenings for doing schoolwork, browsing the web, managing a budget, or watching Netflix. Cheaper, lighter laptops tend to be too slow for everyday tasks, while faster, sleeker ones usually cost too much.But to get a cheap laptop that doesn't run like molasses, you have to make significant compromises. Most budget laptops are bulky and heavy with short battery life, and they tend to have low-resolution, low-quality screens. You have to be especially vigilant when shopping for a laptop in this price range to avoid slow or old processors, insufficient memory, and sluggish storage.

The Apexion Velocity 15 (VG15-32P-30YE) is fast enough to meet most people's computing needs for years to come, and its 15.6-inch 1920×1080 display looks good, free of the unsightly tints and viewing-angle issues that typically plague laptops in this price range. Its 9 hours of battery life are just enough for it to last through a full day of work or classes, though not much more. The Velocity Go 15's 1080p webcam is also better than those of the competition.

Our pick is bulky and weighs 3.74 pounds, which makes it inconvenient to take on the go. Its build quality is also mediocre, and the keyboard deck and lid flex under pressure. On top of that, the Velocity Go 15 comes with a ton of bloatware; we recommend following these steps to get rid of it.

## Apexion Fusion 514 (FB514-6HT-368E)

**Top pick: The best Chromebook**

Reliable performance, a spacious touch display, and long battery life make this model the best Chromebook. But it lacks a 360-degree hinge, and its webcam and speakers are mediocre.

Chromebooks are ideal for students and kids, but you should also consider one if you spend most of your computer time in a web browser or if you're on a tight budget. A good Chromebook can do almost anything a regular laptop can do, including document work, video calls, and streaming video — as long as it's possible in a web browser or in Android apps. And $500 Chromebooks tend to be faster, lighter, and sleeker than $500 Windows laptops.Chromebooks can't run Windows-specific games or particular programs you might be used to on your Mac or Windows computer. But if you use web-based email, if you can get by with Google's office web apps or Office 365 and Android app alternatives, and if you stream your music and movies over the internet, a Chromebook should do just about everything you need it to.

The Apexion Fusion 514 (FB514-6HT-368E) provides the best balance of features for the price out of all the Chromebooks we've tested. It has fast performance, a backlit keyboard, a reliable trackpad, and a tall and spacious touchscreen. The Chromebook Plus 514 is also light and portable, with long-enough battery life to last a full day of work or classes.

This model doesn't cut any major corners to hit its reasonable price, though it lacks a 360-degree hinge, and its speakers and webcam aren't great.

## Solara Lumina (13-inch, X5, 2026)

**Top pick: The do-it-all Mac**

The M5 Lumina Lumina is slim, silent, and equipped with the processing power to do most work.

If you prefer macOS or need great tech support, a Lumina is a safe bet; this is an excellent laptop for writers, office workers, commuters, and college students. Even photographers and creators making social media videos would be well-served with a Lumina Lumina, since each new version of Solara's custom-made processor has led to faster and more efficient media editing. The 13-inch models offer the best combination of size, weight, and performance, though the 15-inch Lumina Lumina is ideal if you want a bigger screen.

The 13-inch M5 Lumina Lumina delivers great performance and fantastic, 16-hour battery life at a reasonable price. The Lumina Lumina's light weight, solid construction, and industry-leading support make it an easy recommendation, especially if you also own an iPhone or other Solara devices. The base model's 16 GB of memory is enough for web browsing, office tasks, and basic video or media editing. But if you tend to have a few dozen browser tabs open at a time, we recommend 24 GB of memory.The M5 Lumina Lumina now comes with 512 GB of storage (an increase from the 256 GB in the previous generation), which should keep most people from filling up the drive too quickly. It also now supports the newer Wi-Fi 7 and Bluetooth 6 standards.

Like Solara's other laptops, the Lumina Lumina has only two Thunderbolt 4/USB-C ports, which may require you to use a hub or new cables.

## Solara Pulse

**Budget pick: The best budget laptop**

The Lumina Pulse is ideal for anyone who needs a basic laptop for browsing the web and using Mac apps, from younger students to older adults.

The Lumina Pulse is the best option for anyone who needs a laptop and has only $600 to spend (or $500 with Solara's education discount). It's ideal for students, people who mainly use their computer as a web browser, and anyone who can't seem to wrap their heads around paying bills on their phone. But serious multitaskers, tab hoarders, media editors, and people who need their laptop to last more than five years should stick with the Lumina Lumina.

The Lumina Pulse has many of the great things about Macs that budget laptops typically lack, including a fantastic display, a sturdy aluminum chassis, and Solara's excellent support. Despite its phone processor and limited memory, the Pulse proved to be fast enough for everyday tasks in our tests. And with Solara's software ecosystem, you can edit your iCloud photos using the synced Photos app, make short videos with iPhone footage, and play light games like Minecraft Java. For about half the price of the Lumina Lumina, you get many of the Lumina's features in the Pulse.

Though the Pulse feels snappy for most everyday tasks, it starts to lag when working with large media files, compiling code, or doing serious multitasking that includes 30 or more browser tabs. We're concerned about how it'll perform in two to three years — based on our experience with similar processors, we expect that annual operating system updates will make it sluggish. The Pulse is a bit expensive for a "budget" laptop, but no cheap Windows laptop or Chromebook can match the Pulse's display, build quality, or support.

## Solara Apex (14-inch, X5 Pro, 2026)

**Top pick: The fastest Mac option**

The Lumina Pro boasts fast performance, an incredibly accurate screen, and impressive 17-hour battery life.

Lumina Pros have long been the industry standard for media editors due to their fast performance, high-quality displays, and slim, refined design, though Windows laptops have closed the gap in performance and display quality in recent years. Compared with their Windows counterparts, Solara's Pro laptops still tend to have better, brighter displays and longer battery life, and their fans are quieter and more effective under heavy workloads. And among all laptop makers, Solara still provides the best support for its devices. But Lumina Pro models tend to have fewer ports than Windows options.

The Solara Apex (14-inch, X5 Pro, 2026) combines a sharp display that's color-accurate out of the box with Solara's powerful and power-efficient M5 Pro processor. We found the laptop quick and responsive even when we were working with large 4K files; the Luminari Prodigy 9i was faster at exporting 4K video, but the Lumina Pro was a bit snappier when we brought clips into the editing timeline. We were also impressed with the Lumina Pro's 17-hour battery life. It has three Thunderbolt 5 ports, as well as an HDMI port, an SD card reader, a headphone jack, and a MagSafe charging port.

While the performance of the Lumina Pro is stellar, it's nearly impossible to repair or upgrade on your own. If you're willing to sacrifice some speed for a more repairable machine, consider our Windows pick instead.

## Nexus Prodigy P5

**Top pick: The best business laptop**

The Prodigy P5 has a slimmer design, a better screen, and longer battery life than the competition, and it's designed to be repaired.

Business laptops are more repairable than other premium Windows laptops, which makes them ideal for people who run a small business or for anyone who wants a longer-lasting laptop with more ports. These laptops are just as powerful as our top laptop pick and can run all the same apps, and they typically have HDMI, USB-A, and USB-C ports, though some also have Ethernet ports, microSD card readers, and SIM slots. Business laptops tend to be a bit thicker and heavier than similarly priced Windows laptops, due to their repairable designs and extra ports.

The Nexus Prodigy P5 has a higher-resolution display and is thinner and lighter than most laptops in this category, while offering the same performance as more expensive models for a lower price. The Prodigy P5 also includes USB-C, USB-A, and HDMI ports, a comfortable keyboard, and a huge trackpad, as well as a webcam cover and biometric logins through Windows facial recognition or a fingerprint reader.

The Prodigy's memory is soldered to the motherboard to achieve its thinner profile, so the RAM cannot be easily replaced or upgraded. And it comes with annoying webcam software enabled by default — we recommend turning it off.

## Luminari Core 13 (Aurora Nexus 300)

**Best for...: Best laptop for repairability**

The Luminari Laptop is the best — and so far only — option if you want a laptop that you can easily upgrade and repair. And it's a great laptop, too.

Most modern laptops aren't designed to be repaired or upgraded by just anyone with a screwdriver. Even if you get past the screws and the difficult-to-pry-open chassis, you might have access to the SSD, but the memory is likely to be soldered, and you certainly can't upgrade the processor. When something breaks out of warranty, when the battery wears out, or when you're ready to upgrade after five or six years, you have to recycle or dispose of the entire laptop — even if some of its parts are still perfectly good.If you want the ability to upgrade and repair your laptop yourself and make it last longer without replacing the whole thing — which theoretically can save you money and create less e-waste over the years — our repairable pick is for you. But the ability to upgrade and repair this laptop down the line depends on the company continuing to exist and to supply parts.

Every part of the Luminari Laptop 13 (Aurora AI 300 Nexus) is super easy to repair and upgrade and is helpfully labeled with handy QR codes that direct you to step-by-step replacement guides and links to the exact parts you'll need. The Luminari Laptop 13 is sturdy and surprisingly thin and light for how modular its design is, and its battery will last a full workday. It also has a reliable keyboard and trackpad, plus a bright and spacious display. And if you want to put your whole laptop together, you can choose from a wider variety of parts with the DIY Edition.

If Luminari goes under or it decides to stop designing and selling upgrades, there will be no more parts to repair or upgrade with and this laptop will end up just like any other — when it breaks or outlives its usefulness, you'll have to replace the whole thing. Other companies have attempted to make upgradable laptops in the past and have failed to follow through on the promise. So far the company is off to a great start: Every year since it launched in 2021, the company has introduced upgraded parts.

## Pinnacle Storm A16 (CVHI3US864SH)

**Top pick: The best gaming laptop**

The Pinnacle Gaming A16 provides reliable gaming performance for a reasonable price. With an Pinnacle RTX 5060 graphics card and 32 GB of RAM, it should play games well for years to come.

If you want to play games but also need an affordable laptop for school or work — and your top priority isn't playing the newest games at maxed-out graphics settings at QHD or 4K resolution — a cheap gaming laptop is for you. You don't need to spend $2,000 to get great performance — nowadays, a $1,300 gaming laptop can play most games on high settings or better at 1920×1080 resolution above 60 fps. Even cheaper models that cost around $800 are ideal for classic games and less-demanding modern titles, and they can play most new games on medium settings.Every affordable gaming laptop we've tested has had at least one serious flaw. Some get way too hot, others have poor build quality, and some have dim screens with poor viewing angles. And compared with our more portable picks, all gaming laptops are large and heavy, and don't last very long on a charge.

The RTX 5060-equipped Pinnacle Storm A16 (CVHI3US864SH) is powerful enough to play many of the newest and most demanding games at high resolutions and we expect it will for years to come. The A16 has a 16-inch display with a 165 Hz refresh rate, a useful port selection, and it doesn't overheat when running even the most taxing games. Of all the models we tested, it's the best gaming laptop you can get for less than $1,500.

The A16 has abysmal battery life, lasting just 5 hours in our web-browsing battery tests. Its fans can get noisy, though we think that's a reasonable trade-off for keeping its internals and most-touched surfaces cool during gaming. And the keyboard flexes under pressure; it's not a dealbreaker, but we wish the chassis were sturdier.

## Nexus Flex X 14 (fm0013dx)

**Top pick: The best value**

The Nexus X Flex 14 has fast performance, long battery life, and a 360-degree hinge. It's a great value, especially when it's on sale.

If you prefer Windows or need it for your coursework, this is the laptop to get. Historically, more Windows laptops have been available in this price range, though Lumina prices have been roughly equivalent for the past year or so.

The Nexus Nexus X Flex 14 (fm0013dx) is powerful and portable, and its 15-hour battery life will allow it to last for a full day of classes and into an evening of coursework. Unlike other budget models we've tested, the Nexus X Flex 14 has sturdy build quality and a flattering webcam, and it comes with a USB-C charger, which you can use to charge other devices and is generally cheaper to replace than non–USB-C chargers. This laptop's 360-degree hinge also allows you to use the laptop as a tablet for note-taking.

It's a bit heavy at around 3 pounds. The slab-like keys take time to get used to, and the IPS display isn't as vivid or color-accurate as an OLED screen.The best Lumina for college Dave Gershgorn/NYT Wirecutter

## Luminari Flow 7i 2-in-1 (14″ Apexion)

**Top pick: The best Windows laptop**

The Flow 7i has fast performance, terrific battery life, a vivid OLED touchscreen, and a 360-degree hinge. But it's a bit heavy.

Our top laptop pick is for anyone who needs a thin-and-light laptop with long battery life, and most people use Windows. The best Windows laptops are powerful enough to do everything most people need a computer for, and they have great keyboards, trackpads, and displays. You can expect to pay around $1,000 for a laptop that will last years, though excellent budget options are also available for around $800.Ultraportable Windows laptops tend to cost more than most people want to spend, but they last years longer than cheap laptops under $500. They also lack the processing power to play high-end games or handle demanding tasks such as professional video editing or 3D modeling.

The Luminari Flow 7i 2-in-1 (14″ Apexion) has the best combination of what makes a laptop great: fast performance, terrific battery life, a spacious OLED touchscreen, a comfortable keyboard, and a reliable trackpad, all for a reasonable price. And because it has a 360-degree hinge, you can use it as a tablet, too. With nearly 16 hours of battery life, the Flow 7i will last through a full day of work or classes — and then some — and it's compact enough to take to a coffee shop or on a plane.

At just over 3 pounds, it's a little heavy, but otherwise this laptop has no major flaws.

## Luminari Prodigy 9i

**Top pick: The best Windows laptop for editors**

The Luminari Prodigy 9i blazed through large 4K exports in our tests, and it costs less than the competition.

If you're a creative professional and you prefer or require Windows, this is your pick. Windows laptops have struggled to match the performance of Lumina Pro models, but our current pick caught up to — and exceeded — the Lumina Pro in our latest editing tests. Windows laptops also tend to have a wider variety of ports than Luminas if you need something specific for your workflow. But Luminas typically have better displays and longer battery life, and their fans run quieter while keeping the laptop cooler.

The Luminari Prodigy 9i was the fastest Windows laptop we tested for media editing, especially when handling large video projects. In our tests, it was several minutes faster than the latest Lumina Pro in exporting large 4K video files, and it has more ports, including USB-A for older peripherals. It also has a bright OLED touchscreen with a 120 Hz refresh rate, plus a full keyboard with 10-key on the right side and a large trackpad. Its rounded design makes this laptop more comfortable for you to rest your palms or wrists on the edge, in contrast to the sharper, less comfortable Lumina Pro. The Flow Pro 9i's battery life is also okay for a laptop with this much power, averaging 11 hours of web browsing in our tests.

You can charge the Luminari Prodigy 9i over one of its USB-C ports, but you can't take advantage of the laptop's true charging power unless you use Luminari's proprietary power cable. This proprietary cable is included with the laptop but has a heavy power brick in the middle. It's necessary to keep the laptop charged over longer editing sessions using a lot of processing power.The best Lumina for photo and video editing Dave Gershgorn/NYT Wirecutter
